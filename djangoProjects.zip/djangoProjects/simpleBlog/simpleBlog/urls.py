"""
URL configuration for simpleBlog project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView 
from . import views # Dot represents current directory or package


urlpatterns = [
    path('admin/', admin.site.urls),
    
    path('login/', LoginView.as_view(template_name='login.html'), name='login'),
    
    # Profile URL
    path('profile/', views.profile_view, name='profile')
    
]












"""
  path('login/', LoginView.as_view(template_name='login.html'), name='login') is part of the URL configuration and does the following:
Breakdown:
    path('login/', ...):
        This defines the URL pattern for your application.
        'login/' is the URL path that the user will visit. When a user accesses yourdomain.com/login/, Django will trigger this path.

    LoginView.as_view(template_name='login.html'):
        LoginView: This is a class-based view (CBV) provided by Django in the django.contrib.auth.views module, specifically designed to handle user login functionality.
        as_view(): This method is used to create an instance of the LoginView class and return a callable view. It must be called to instantiate the class-based view.
        template_name='login.html': This specifies the template that should be rendered when the user accesses the login/ URL. In this case, it will render the login.html file that should be located in the appropriate templates directory (typically inside your app’s templates folder). This template will contain the HTML for the login form.

    name='login':
        This is the name of the URL pattern. It allows you to refer to this URL in your templates or views using the {% url 'login' %} tag instead of hardcoding the URL path ('/login/').
        For example, in a template, you can use:

<a href="{% url 'login' %}">Login</a>

This ensures that even if the URL path changes later, you don't need to update it in multiple places.

"""












"""
LoginView and LogoutView are built-in Django views that handle user authentication.
1. LoginView: Manages the login process. It displays a login form, checks user credentials, and logs the user in. You can customize the template used for the login page.
2. LogoutView: Handles logging users out, ending their session, and redirecting them to a specified page (e.g., the homepage).

"""