from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def hello(request):
    peoples = [
        {'name': 'Sushil Upadhayay', 'age': 21},
        {'name': 'Robair aakash', 'age': 13},
        {'name': 'Aakash Sharma', 'age': 25},
        {'name': 'Ganga Upadhayay', 'age': 41},
        {'name': 'Robair Ganga', 'age': 16},
        {'name': 'Rajesh Sharma', 'age': 12},
        {'name': 'Rajesh Upadhayay', 'age': 51},
        {'name': 'Robair Rajesh', 'age': 15},
        {'name': 'ShivaKanta Upadhayay', 'age': 29}
    ]
    return render(request, "index.html", context = {'peoples': peoples}) # If index.html is inside another folder inside template folder than write "folder/index.html"

def about(request):
    return render(request, "about.html")

def contact(request):
    return render(request, "contact.html")


"""
So why not use HttpResponse() in place of render(). Is it because we need to manually load, render and return the rendered template while using HttpResponse() which 
we don't have to do when using render(). And HttpResponse() is generally used when returning the plain html response and render() is used when sending dynamic html
responses from server.
"""