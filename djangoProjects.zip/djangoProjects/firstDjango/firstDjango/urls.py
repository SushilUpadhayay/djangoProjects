from django.contrib import admin
from django.urls import path
from home.views import hello # home ko view bata hello lai import gar
from home.views import contact
from home.views import about



urlpatterns = [
    path('', hello, name = "hello"), 
    
    path("contact/", contact, name = "contact"),
    
    path("about/", about, name = "about"),
    
    # It is not necessary to have forward slash after ghar
    
    path('admin/', admin.site.urls),
]
"""
This is the URL pattern. An empty string ('') means it matches the root URL (/), i.e., the homepage of the site.
hello: This is the view function that will handle the request when someone visits the root URL. You should have
defined this view in your views.py file.
name="hello": This gives a name to the URL pattern, which is useful for referring to this URL in templates or other
parts of your code (for example, when generating links).
  
  """