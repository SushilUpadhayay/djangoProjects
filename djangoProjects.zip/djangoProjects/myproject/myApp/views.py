from django.shortcuts import render
from django.http import HttpResponse

def main_view(request):
    return render(request, 'Main_view.html')

def login_view(request):
    return render(request, 'login.html')

def profile_view(request):
    return render(request, 'profile.html')

def search_view(request):
    return render(request, 'search.html')

def home_view(request):
    return render(request, 'home.html')